<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from GET request
    $phone_number = isset($_GET['phone_number']) ? sanitize_input($_GET['phone_number']) : '';

    // Check if phone number is provided
    if (empty($phone_number)) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Phone number is required.']);
        exit;
    }

    // Prepare SQL statement to check if user exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE phone_number = :phone_number");

    // Bind parameter to the SQL statement
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();

    // Fetch the count
    $count = $stmt->fetchColumn();

    // Check if user exists
    if ($count > 0) {
        // User exists
        echo 'true';
    } else {
        // User does not exist
        echo 'false';
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error status
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
