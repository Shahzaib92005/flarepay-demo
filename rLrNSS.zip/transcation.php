<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

// Function to generate a unique 14-digit transaction ID
function generateTransactionId() {
    $prefix = date('ymd'); // 6-digit date prefix (YYMMDD)
    $random = mt_rand(100000, 999999); // 6-digit random number
    return $prefix . $random; // Concatenate to make 14 digits
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from POST request
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are present
    if (!isset($data['sender_phone'], $data['receiver_phone'], $data['amount'], $data['user_account_pin'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
        exit;
    }

    // Sanitize data
    $sender_phone = sanitize_input($data['sender_phone']);
    $receiver_phone = sanitize_input($data['receiver_phone']);
    $amount = (float) sanitize_input($data['amount']);
  
    $user_account_pin = sanitize_input($data['user_account_pin']);

    // Fetch sender details
    $stmt = $pdo->prepare("SELECT name, balance, cnic_number, user_account_pin FROM users WHERE phone_number = :phone_number");
    $stmt->bindParam(':phone_number', $sender_phone);
    $stmt->execute();
    $sender = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sender) {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'Sender not found.']);
        exit;
    }

    // Verify the account pin and CNIC number
    if ($sender['user_account_pin'] !== $user_account_pin) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Incorrect account pin.']);
        exit;
    }

   
    // Fetch receiver details
    $stmt = $pdo->prepare("SELECT name, balance FROM users WHERE phone_number = :phone_number");
    $stmt->bindParam(':phone_number', $receiver_phone);
    $stmt->execute();
    $receiver = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$receiver) {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'Receiver not found.']);
        exit;
    }

    // Ensure sender is not sending money to themselves
    if ($sender_phone === $receiver_phone) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Sender cannot send money to themselves.']);
        exit;
    }

    // Check if sender has sufficient balance
    if ($sender['balance'] < $amount) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Insufficient balance.']);
        exit;
    }

    // Begin transaction
    $pdo->beginTransaction();

    try {
        // Generate a unique 14-digit transaction ID
        $transaction_id = generateTransactionId();

        // Update sender's balance
        $new_sender_balance = $sender['balance'] - $amount;
        $stmt = $pdo->prepare("UPDATE users SET balance = :balance WHERE phone_number = :phone_number");
        $stmt->bindParam(':balance', $new_sender_balance);
        $stmt->bindParam(':phone_number', $sender_phone);
        $stmt->execute();

        // Update receiver's balance
        $new_receiver_balance = $receiver['balance'] + $amount;
        $stmt = $pdo->prepare("UPDATE users SET balance = :balance WHERE phone_number = :phone_number");
        $stmt->bindParam(':balance', $new_receiver_balance);
        $stmt->bindParam(':phone_number', $receiver_phone);
        $stmt->execute();

        // Record transaction for sender
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, phone_number, sender_name, receiver_name, sender_phone_number, receiver_phone_number, transaction_type, amount, description, timestamp) VALUES (:transaction_id, :phone_number, :sender_name, :receiver_name, :sender_phone_number, :receiver_phone_number, 'send', :amount, :description, NOW())");
        $stmt->bindParam(':transaction_id', $transaction_id);
        $stmt->bindParam(':phone_number', $sender_phone);
        $stmt->bindParam(':sender_name', $sender['name']);
        $stmt->bindParam(':receiver_name', $receiver['name']);
        $stmt->bindParam(':sender_phone_number', $sender_phone);
        $stmt->bindParam(':receiver_phone_number', $receiver_phone);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindValue(':description', 'Sent to ' . $receiver['name']);
        $stmt->execute();

        // Record transaction for receiver
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, phone_number, sender_name, receiver_name, sender_phone_number, receiver_phone_number, transaction_type, amount, description, timestamp) VALUES (:transaction_id, :phone_number, :sender_name, :receiver_name, :sender_phone_number, :receiver_phone_number, 'receive', :amount, :description, NOW())");
        $stmt->bindParam(':transaction_id', $transaction_id);
        $stmt->bindParam(':phone_number', $receiver_phone);
        $stmt->bindParam(':sender_name', $sender['name']);
        $stmt->bindParam(':receiver_name', $receiver['name']);
        $stmt->bindParam(':sender_phone_number', $sender_phone);
        $stmt->bindParam(':receiver_phone_number', $receiver_phone);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindValue(':description', 'Received from ' . $sender['name']);
        $stmt->execute();

        // Commit transaction
        $pdo->commit();

        // Respond with success and transaction ID
        http_response_code(200); // OK status
        echo json_encode([
            'status' => 'success',
            'message' => 'Transaction completed successfully.',
            'transaction_id' => $transaction_id
        ]);

    } catch (Exception $e) {
        // Rollback transaction if there is an error
        $pdo->rollBack();
        http_response_code(500); // Internal Server Error
        echo json_encode([
            'status' => 'error',
            'message' => 'Transaction failed: ' . $e->getMessage()
        ]);
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
