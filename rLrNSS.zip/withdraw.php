<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// Create a new MySQLi instance
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error]);
    exit;
}

// Get raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate JSON data
if (json_last_error() !== JSON_ERROR_NONE) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// Retrieve and sanitize data from JSON
$phone_number = isset($data['phone_number']) ? $mysqli->real_escape_string($data['phone_number']) : '';
$amount_request = isset($data['amount_request']) ? $mysqli->real_escape_string($data['amount_request']) : '';
$bank_name = isset($data['bank_name']) ? $mysqli->real_escape_string($data['bank_name']) : '';
$account_number = isset($data['account_number']) ? $mysqli->real_escape_string($data['account_number']) : '';

if (empty($phone_number) || empty($amount_request) || !is_numeric($amount_request) || empty($bank_name) || empty($account_number)) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Phone number, amount request, bank name, and account number are required.']);
    exit;
}

// Fetch user details
$result = $mysqli->query("SELECT * FROM users WHERE phone_number = '$phone_number'");

if ($result->num_rows === 0) {
    header('Content-Type: application/json');
    http_response_code(404); // Not Found
    echo json_encode(['status' => 'error', 'message' => 'User not found.']);
    exit;
}

$user = $result->fetch_assoc();
$user_balance = $user['balance'];

// Check if user has sufficient balance
if ($user_balance < $amount_request) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Insufficient balance.']);
    exit;
}

// Begin transaction
$mysqli->begin_transaction();

try {
    // Prepare and execute the SQL statement to insert the withdrawal request
    $stmt = $mysqli->prepare("INSERT INTO withdraw_request (phone_number, amount_request, bank_name, account_number, status) VALUES (?, ?, ?, ?, 'pending')");
    $stmt->bind_param("ssss", $phone_number, $amount_request, $bank_name, $account_number);
    $stmt->execute();
    $withdraw_request_id = $stmt->insert_id; // Get the last inserted ID
    $stmt->close();

    // Update user balance
    $new_user_balance = $user_balance - $amount_request;
    $mysqli->query("UPDATE users SET balance = '$new_user_balance' WHERE phone_number = '$phone_number'");

    // Record transaction for withdrawal
    $transaction_id = uniqid(); // Generate a unique transaction ID
    $mysqli->query("INSERT INTO transactions (transaction_id, phone_number, transaction_type, amount, description, timestamp, sender_name, receiver_name, sender_phone_number, receiver_phone_number) 
                    VALUES ('$transaction_id', '$phone_number', 'send', '$amount_request', 'Withdrawal request processed', NOW(), 'System', 'Bank', '$phone_number', 'Bank')");

    // Commit transaction
    $mysqli->commit();

    // Respond with success
    header('Content-Type: application/json');
    http_response_code(201); // Created
    echo json_encode([
        'status' => 'success',
        'message' => 'Withdrawal request processed successfully.',
        'withdraw_request_id' => $withdraw_request_id
    ]);

} catch (Exception $e) {
    // Rollback transaction if there is an error
    $mysqli->rollback();
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Transaction failed: ' . $e->getMessage()
    ]);
}

$mysqli->close();
?>
