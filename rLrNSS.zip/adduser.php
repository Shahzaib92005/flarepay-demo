<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from POST request
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are present
    if (!isset($data['phone_number'], $data['name'], $data['dob'], $data['cnic_number'], $data['cnic_issue_date'], $data['cnic_expiry_date'], $data['account_status'], $data['device_id'], $data['user_address'], $data['date_account_created'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
        exit;
    }

    // Sanitize data
    $phone_number = sanitize_input($data['phone_number']);
    $name = sanitize_input($data['name']);
    $dob = sanitize_input($data['dob']);
    $cnic_number = sanitize_input($data['cnic_number']);
    $cnic_issue_date = sanitize_input($data['cnic_issue_date']);
    $cnic_expiry_date = sanitize_input($data['cnic_expiry_date']);
    $account_status = sanitize_input($data['account_status']);
    $device_id = sanitize_input($data['device_id']);
    $user_address = sanitize_input($data['user_address']);
    $date_account_created = sanitize_input($data['date_account_created']);

    // Check if user with the same phone number already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE phone_number = :phone_number");
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();
    $userExists = $stmt->fetchColumn();

    if ($userExists > 0) {
        http_response_code(409); // Conflict
        echo json_encode(['status' => 'error', 'message' => 'User already exists.']);
        exit;
    }

    // Prepare SQL statement to insert user data
    $stmt = $pdo->prepare("INSERT INTO users (phone_number, name, dob, cnic_number, cnic_issue_date, cnic_expiry_date, account_status, device_id, user_address, date_account_created) 
        VALUES (:phone_number, :name, :dob, :cnic_number, :cnic_issue_date, :cnic_expiry_date, :account_status, :device_id, :user_address, :date_account_created)");

    // Bind parameters to the SQL statement
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':dob', $dob);
    $stmt->bindParam(':cnic_number', $cnic_number);
    $stmt->bindParam(':cnic_issue_date', $cnic_issue_date);
    $stmt->bindParam(':cnic_expiry_date', $cnic_expiry_date);
    $stmt->bindParam(':account_status', $account_status);
    $stmt->bindParam(':device_id', $device_id);
    $stmt->bindParam(':user_address', $user_address);
    $stmt->bindParam(':date_account_created', $date_account_created);

    // Execute the statement
    $stmt->execute();

    // Respond with success
    http_response_code(201); // Created status
    echo json_encode([
        'status' => 'success',
        'message' => 'Account Creation Completed.'
    ]);

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error status
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
