<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// API Key for authentication
$apiKey = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d'; // Replace with your actual API key

// Retrieve API Key from headers
$headers = apache_request_headers();
if (!isset($headers['Authorization']) || $headers['Authorization'] !== $apiKey) {
    http_response_code(401); // Unauthorized
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

// Create a new PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database connection error']);
    exit;
}

// Get JSON data from POST request
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// Retrieve and sanitize data from JSON
$merchant_id = isset($input['merchant_id']) ? $input['merchant_id'] : '';
$merchant_name = isset($input['merchant_name']) ? $input['merchant_name'] : '';
$user_id = isset($input['user_id']) ? $input['user_id'] : '';
$amount_request = isset($input['amount_request']) ? $input['amount_request'] : '';
$description = isset($input['description']) ? $input['description'] : '';
$payment_status = isset($input['payment_status']) ? $input['payment_status'] : '';

// Validate input
if (empty($merchant_id) || empty($merchant_name) || empty($user_id) || !is_numeric($amount_request) || !in_array($payment_status, ['pending', 'approved', 'rejected'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid input data']);
    exit;
}

try {
    // Check if the merchant exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM merchants WHERE merchant_id = ?");
    $stmt->execute([$merchant_id]);
    $merchantExists = $stmt->fetchColumn() > 0;

    if (!$merchantExists) {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'Merchant does not exist']);
        exit;
    }

    // Prepare SQL statement for payment request
    $stmt = $pdo->prepare("INSERT INTO payment_request (merchant_id, merchant_name, user_id, amount_request, request_at, description, payment_status) VALUES (?, ?, ?, ?, NOW(), ?, ?)");
    
    // Execute SQL statement
    $stmt->execute([$merchant_id, $merchant_name, $user_id, $amount_request, $description, $payment_status]);

    // Get the last inserted request ID
    $request_id = $pdo->lastInsertId();

    http_response_code(201); // Created
    echo json_encode([
        'status' => 'success',
        'message' => 'Payment request submitted successfully',
        'request_id' => $request_id
    ]);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
