<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// Create a new MySQLi instance
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error]);
    exit;
}

// Get raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate JSON data
if (json_last_error() !== JSON_ERROR_NONE) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// Retrieve and sanitize data from JSON
$request_id = isset($data['request_id']) ? $mysqli->real_escape_string($data['request_id']) : '';

if (empty($request_id)) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Request ID is required.']);
    exit;
}

// Update payment request status to 'rejected'
if ($mysqli->query("UPDATE payment_request SET payment_status = 'rejected' WHERE id = '$request_id'")) {
    header('Content-Type: application/json');
    http_response_code(200); // OK
    echo json_encode(['status' => 'success', 'message' => 'Payment request rejected successfully.']);
} else {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Failed to reject payment request.']);
}

$mysqli->close();
?>
