<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// Create a new MySQLi instance
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

// Retrieve user phone number from GET request
$user_phone_number = isset($_GET['user_phone_number']) ? $mysqli->real_escape_string($_GET['user_phone_number']) : '';

// Validate input
if (empty($user_phone_number)) {
    die('User phone number is required.');
}

// Fetch user details
$user_query = "SELECT * FROM users WHERE phone_number = '$user_phone_number'";
$user_result = $mysqli->query($user_query);

if (!$user_result) {
    die('Error in SQL query: ' . $mysqli->error);
}

if ($user_result->num_rows === 0) {
    die('User not found.');
}

$user = $user_result->fetch_assoc();
$user_name = $user['name'];
$user_address = isset($user['user_address']) ? $user['user_address'] : 'Address not provided';
$user_email = isset($user['email']) ? $user['email'] : 'Email not provided';
$user_balance = number_format($user['balance'], 2);

// Fetch user transactions
$transaction_query = "SELECT * FROM transactions WHERE phone_number = '$user_phone_number' ORDER BY timestamp DESC";
$transaction_result = $mysqli->query($transaction_query);

if (!$transaction_result) {
    die('Error in SQL query: ' . $mysqli->error);
}

// Close the database connection
$mysqli->close();

// Include the FPDF library
require('fpdf.php');

// Create a new PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Title and header
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetTextColor(0, 194, 124); // Teal color for title
$pdf->Cell(0, 10, 'FlarePay Account Statement 🌟', 0, 1, 'C');
$pdf->Ln(10);

// User Information Section
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(255, 255, 255); // White color for section headers
$pdf->Cell(0, 10, 'User Information 👤', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(230, 230, 230); // Light gray for content
$pdf->Cell(0, 10, 'Name: ' . $user_name, 0, 1);
$pdf->Cell(0, 10, 'Address: ' . $user_address, 0, 1);
$pdf->Cell(0, 10, 'Phone: ' . $user_phone_number, 0, 1);
$pdf->Cell(0, 10, 'Email: ' . $user_email, 0, 1);
$pdf->Cell(0, 10, 'Current Balance: PKR ' . $user_balance, 0, 1);
$pdf->Ln(10);

// Transaction History Section
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(255, 255, 255); // White color for section headers
$pdf->Cell(0, 10, 'Transaction History 📜', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(230, 230, 230); // Light gray for content

// Table header
$pdf->SetFillColor(0, 150, 136); // Teal color for header background
$pdf->Cell(40, 10, 'Date 📅', 1, 0, 'C', true);
$pdf->Cell(90, 10, 'Description 📝', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Debit 💸', 1, 0, 'C', true);
$pdf->Cell(30, 10, 'Credit 💰', 1, 1, 'C', true);

while ($row = $transaction_result->fetch_assoc()) {
    $pdf->SetFillColor(33, 33, 33); // Dark gray background for rows
    $pdf->Cell(40, 10, date('M d, Y', strtotime($row['timestamp'])), 1, 0, 'L', true);
    $pdf->Cell(90, 10, $row['description'], 1, 0, 'L', true);
    if ($row['transaction_type'] == 'send') {
        $pdf->Cell(30, 10, '-PKR ' . number_format($row['amount'], 2), 1, 0, 'R', true);
        $pdf->Cell(30, 10, '', 1, 1, 'R', true);
    } else {
        $pdf->Cell(30, 10, '', 1, 0, 'R', true);
        $pdf->Cell(30, 10, '+PKR ' . number_format($row['amount'], 2), 1, 1, 'R', true);
    }
}

// Ending Balance Section
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(255, 255, 255); // White color for section headers
$pdf->Cell(0, 10, 'Ending Balance 💵', 0, 1);
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(230, 230, 230); // Light gray for content
$pdf->Cell(0, 10, 'PKR ' . $user_balance, 0, 1);

// Output the PDF to the browser
$pdf->Output('D', 'Account_Statement_' . $user_phone_number . '.pdf');
?>