<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// API Key for authentication


// Create a new PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database connection error']);
    exit;
}

// Get user_id from API request
$user_id = filter_input(INPUT_GET, 'user_id', FILTER_SANITIZE_NUMBER_INT);

// Validate input
if (empty($user_id) || !is_numeric($user_id)) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid user ID']);
    exit;
}

try {
    // Prepare SQL statement to get pending payment requests
    $stmt = $pdo->prepare("SELECT * FROM payment_request WHERE user_id = ? AND payment_status = 'pending'");
    
    // Execute SQL statement
    $stmt->execute([$user_id]);

    // Fetch all results
    $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    if ($requests) {
        http_response_code(200); // OK
        echo json_encode( $requests);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'success', 'message' => 'No pending payment requests found']);
    }
} catch (PDOException $e) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
