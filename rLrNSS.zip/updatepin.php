<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from POST request
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are present
    if (!isset($data['phone_number'], $data['current_pin'], $data['new_pin'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
        exit;
    }

    // Sanitize data
    $phone_number = sanitize_input($data['phone_number']);
    $current_pin = sanitize_input($data['current_pin']);
    $new_pin = sanitize_input($data['new_pin']);

    // Check if user exists and verify current PIN
    $stmt = $pdo->prepare("SELECT user_account_pin FROM users WHERE phone_number = :phone_number");
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if ($user['user_account_pin'] === $current_pin) {
            // Update user PIN
            $stmt = $pdo->prepare("UPDATE users SET user_account_pin = :new_pin WHERE phone_number = :phone_number");
            $stmt->bindParam(':new_pin', $new_pin);
            $stmt->bindParam(':phone_number', $phone_number);
            $stmt->execute();

            // Respond with success
            http_response_code(200); // OK status
            echo json_encode([
                'status' => 'success',
                'message' => 'PIN updated successfully.'
            ]);
        } else {
            // Current PIN does not match
            http_response_code(400); // Bad Request
            echo json_encode([
                'status' => 'error',
                'message' => 'Current PIN is incorrect.'
            ]);
        }
    } else {
        // User not found
        http_response_code(404); // Not Found
        echo json_encode([
            'status' => 'error',
            'message' => 'User not found.'
        ]);
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
