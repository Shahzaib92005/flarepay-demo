<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// Create a new MySQLi instance
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error]);
    exit;
}

// Get raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate JSON data
if (json_last_error() !== JSON_ERROR_NONE) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// Retrieve and sanitize data from JSON
$phone_number = isset($data['phone_number']) ? $mysqli->real_escape_string($data['phone_number']) : '';
$amount_request = isset($data['amount_request']) ? $mysqli->real_escape_string($data['amount_request']) : '';
$bank_transaction_id = isset($data['bank_transaction_id']) ? $mysqli->real_escape_string($data['bank_transaction_id']) : '';

if (empty($phone_number) || empty($amount_request) || !is_numeric($amount_request)) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Phone number and amount request are required.']);
    exit;
}

// Prepare and execute the SQL statement to insert the data
$stmt = $mysqli->prepare("INSERT INTO topup_request (phone_number, amount_request, bank_transaction_id, status) VALUES (?, ?, ?, 'pending')");
$stmt->bind_param("sss", $phone_number, $amount_request, $bank_transaction_id);

if ($stmt->execute()) {
    header('Content-Type: application/json');
    http_response_code(201); // Created
    echo json_encode(['status' => 'success', 'message' => 'Top-up request added successfully.']);
} else {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Failed to add top-up request.']);
}

$stmt->close();
$mysqli->close();
?>
