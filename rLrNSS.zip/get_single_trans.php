<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

// Function to mask phone numbers
function mask_phone_number($phone_number) {
    if (strlen($phone_number) > 4) {
        return str_repeat('.', strlen($phone_number) - 4) . substr($phone_number, -4);
    }
    return $phone_number;
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Retrieve and sanitize data from GET request
    $transaction_id = isset($_GET['transaction_id']) ? sanitize_input($_GET['transaction_id']) : '';
    $phone_number = isset($_GET['phone_number']) ? sanitize_input($_GET['phone_number']) : '';

    // Check if required parameters are provided
    if (empty($transaction_id) || empty($phone_number)) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Transaction ID and phone number are required.']);
        exit;
    }

    // Prepare SQL statement to get transaction details
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE transaction_id = :transaction_id AND (phone_number = :phone_number)");

    // Bind parameters to the SQL statement
    $stmt->bindParam(':transaction_id', $transaction_id);
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();

    // Fetch transaction details
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($transaction) {
        // Mask phone numbers
        $transaction['sender_phone_number'] = mask_phone_number($transaction['sender_phone_number']);
        $transaction['receiver_phone_number'] = mask_phone_number($transaction['receiver_phone_number']);

        // Respond with transaction details
        http_response_code(200); // OK
        echo json_encode([
            'status' => 'success',
            'transaction_details' => $transaction
        ]);
    } else {
        // Transaction not found
        http_response_code(404); // Not Found
        echo json_encode([
            'status' => 'error',
            'message' => 'Transaction not found for this ID and phone number.'
        ]);
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
