<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from GET request
    $phone_number = isset($_GET['phone_number']) ? sanitize_input($_GET['phone_number']) : '';

    // Check if phone number is provided
    if (empty($phone_number)) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Phone number is required.']);
        exit;
    }

    // Prepare SQL statement to get card details
    $stmt = $pdo->prepare("SELECT card_number, phone_number, card_expiry, card_status, is_delivered, screen_to_show, tracking_id
        FROM card_details WHERE phone_number = :phone_number");

    // Bind parameter to the SQL statement
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();

    // Fetch card details
    $card_details = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($card_details) {
        // Respond with card details
        http_response_code(200); // OK
        echo json_encode(
             $card_details
        );
    } else {
        // Card details not found
        http_response_code(404); // Not Found
        echo json_encode([
            'status' => 'error',
            'message' => 'Card details not found for this phone number.'
        ]);
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
