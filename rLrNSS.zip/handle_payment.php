<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// Create a new MySQLi instance
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error]);
    exit;
}

// Get raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate JSON data
if (json_last_error() !== JSON_ERROR_NONE) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// Retrieve and sanitize data from JSON
$request_id = isset($data['request_id']) ? $mysqli->real_escape_string($data['request_id']) : '';
$user_phone_number = isset($data['user_phone_number']) ? $mysqli->real_escape_string($data['user_phone_number']) : '';

if (empty($request_id) || empty($user_phone_number)) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Request ID and user phone number are required.']);
    exit;
}

// Fetch payment request details
$result = $mysqli->query("SELECT * FROM payment_request WHERE id = '$request_id' AND user_id = '$user_phone_number' AND payment_status = 'pending'");

if ($result->num_rows === 0) {
    header('Content-Type: application/json');
    http_response_code(404); // Not Found
    echo json_encode(['status' => 'error', 'message' => 'Payment request not found or already processed.']);
    exit;
}

$payment_request = $result->fetch_assoc();
$merchant_id = $payment_request['merchant_id'];
$amount = $payment_request['amount_request'];

// Fetch merchant details
$merchant_result = $mysqli->query("SELECT * FROM merchants WHERE merchant_id = '$merchant_id'");

if ($merchant_result->num_rows === 0) {
    header('Content-Type: application/json');
    http_response_code(404); // Not Found
    echo json_encode(['status' => 'error', 'message' => 'Merchant not found.']);
    exit;
}

$merchant = $merchant_result->fetch_assoc();
$merchant_balance = $merchant['merchant_account_balance'];
$merchant_name = $merchant['merchant_name']; // Fetch merchant name

// Fetch user details
$user_result = $mysqli->query("SELECT * FROM users WHERE phone_number = '$user_phone_number'");

if ($user_result->num_rows === 0) {
    header('Content-Type: application/json');
    http_response_code(404); // Not Found
    echo json_encode(['status' => 'error', 'message' => 'User not found.']);
    exit;
}

$user = $user_result->fetch_assoc();
$user_balance = $user['balance'];
$user_name = $user['name']; // Fetch user name

// Check if user has sufficient balance
if ($user_balance < $amount) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Insufficient balance.']);
    exit;
}

// Cashback and fee calculations
$cashback_percentage = 0.10; // 10%
$cashback_cap = 200;
$transaction_fee_percentage = 0.005; // 0.5%

// Calculate cashback
$calculated_cashback = $amount * $cashback_percentage;
$cashback = min($calculated_cashback, $cashback_cap);

// Calculate transaction fee
$transaction_fee = $amount * $transaction_fee_percentage;

// Adjust amounts
$amount_sent_to_merchant = $amount - $cashback - $transaction_fee;
$new_user_balance = $user_balance - $amount + $cashback; // Deduct payment and add cashback
$new_merchant_balance = $merchant_balance + $amount_sent_to_merchant;

// Begin transaction
$mysqli->begin_transaction();

try {
    // Update user balance
    $mysqli->query("UPDATE users SET balance = '$new_user_balance' WHERE phone_number = '$user_phone_number'");

    // Update merchant balance
    $mysqli->query("UPDATE merchants SET merchant_account_balance = '$new_merchant_balance' WHERE merchant_id = '$merchant_id'");

    // Record transaction for user (payment)
    $transaction_id = uniqid(); // Generate a unique transaction ID
    $mysqli->query("INSERT INTO transactions (transaction_id, phone_number, transaction_type, amount, transaction_fee, balance_before_transaction, description, timestamp, sender_name, receiver_name, sender_phone_number, receiver_phone_number) VALUES ('$transaction_id', '$user_phone_number', 'send', '$amount', '$transaction_fee', '$user_balance', 'Payment to merchant $merchant_name with cashback and fee deduction', NOW(), '$user_name', '$merchant_name', '$user_phone_number', '$merchant_id')");

    // Record transaction for merchant (payment)
    $mysqli->query("INSERT INTO transactions (transaction_id, phone_number, transaction_type, amount, transaction_fee, balance_before_transaction, description, timestamp, sender_name, receiver_name, sender_phone_number, receiver_phone_number) VALUES ('$transaction_id', '$merchant_id', 'receive', '$amount_sent_to_merchant', '$transaction_fee', '$merchant_balance', 'Payment received from user $user_phone_number with fee deduction', NOW(), '$user_name', '$merchant_name', '$user_phone_number', '$merchant_id')");

    // Record cashback transaction for user
    $cashback_transaction_id = uniqid(); // Generate a unique transaction ID for cashback
    $mysqli->query("INSERT INTO transactions (transaction_id, phone_number, transaction_type, amount, transaction_fee, balance_before_transaction, description, timestamp, sender_name, receiver_name, sender_phone_number, receiver_phone_number) VALUES ('$cashback_transaction_id', '$user_phone_number', 'receive', '$cashback', '0.00', '$new_user_balance', 'Cashback received', NOW(), 'System', '$user_name', '', '$user_phone_number')");

    // Record cashback adjustment for merchant (negative adjustment)
    $merchant_cashback_transaction_id = uniqid(); // Generate a unique transaction ID for merchant cashback adjustment
    $mysqli->query("INSERT INTO transactions (transaction_id, phone_number, transaction_type, amount, transaction_fee, balance_before_transaction, description, timestamp, sender_name, receiver_name, sender_phone_number, receiver_phone_number) VALUES ('$merchant_cashback_transaction_id', '$merchant_id', 'send', '$cashback', '0.00', '$new_merchant_balance', 'Cashback adjustment', NOW(), 'System', '$merchant_name', '', '$merchant_id')");

    // Update payment request status
    $mysqli->query("UPDATE payment_request SET payment_status = 'approved' WHERE id = '$request_id'");

    // Commit transaction
    $mysqli->commit();

    // Respond with success
    header('Content-Type: application/json');
    http_response_code(200); // OK
    echo json_encode([
        'status' => 'success',
        'message' => 'Payment processed successfully.',
        'transaction_id' => $transaction_id
    ]);

} catch (Exception $e) {
    // Rollback transaction if there is an error
    $mysqli->rollback();
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Transaction failed: ' . $e->getMessage()
    ]);
}

$mysqli->close();
?>
