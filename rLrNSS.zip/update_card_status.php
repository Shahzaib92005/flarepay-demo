<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from POST request
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are present
    if (!isset($data['phone_number'], $data['card_number'], $data['status'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
        exit;
    }

    // Sanitize data
    $phone_number = sanitize_input($data['phone_number']);
    $card_number = sanitize_input($data['card_number']);
    $status = filter_var($data['status'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

    if ($status === null) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Invalid status value.']);
        exit;
    }

    // Determine card status
    $card_status = $status ? 'inactive' : 'active';

    // Prepare SQL statement to update the card status
    $stmt = $pdo->prepare("UPDATE card_details SET card_status = :card_status WHERE phone_number = :phone_number AND card_number = :card_number");

    // Bind parameters to the SQL statement
    $stmt->bindParam(':card_status', $card_status);
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->bindParam(':card_number', $card_number);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        // Respond with success
        http_response_code(200); // OK
        echo json_encode(['status' => 'success', 'message' => 'Card status updated successfully.']);
    } else {
        // No rows affected
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'Card details not found or status unchanged.']);
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
