<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from POST request
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are present
    if (!isset($data['phone_number'], $data['card_expiry'], $data['card_status'], $data['is_delivered'], $data['address'], $data['city'], $data['alternate_phone_number'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
        exit;
    }

    // Sanitize data
    $phone_number = sanitize_input($data['phone_number']);
    $card_expiry = sanitize_input($data['card_expiry']);
    $card_status = sanitize_input($data['card_status']);
    $is_delivered = filter_var($data['is_delivered'], FILTER_VALIDATE_BOOLEAN);
    $address = sanitize_input($data['address']);
    $city = sanitize_input($data['city']);
    $alternate_phone_number = sanitize_input($data['alternate_phone_number']);

    // Auto-generate card number in the format PKFP############
    $card_number = 'PKFP' . str_pad(rand(0, 99999999), 8, '0', STR_PAD_LEFT);

    // Check if a record with the same phone number already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM card_details WHERE phone_number = :phone_number");
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        // Phone number already exists
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'A card record with this phone number already exists.']);
        exit;
    }

    // Check user's balance
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE phone_number = :phone_number");
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // User not found
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'User not found.']);
        exit;
    }

    $balance = $user['balance'];
    if ($balance < 500) {
        // Insufficient balance
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Insufficient balance.']);
        exit;
    }

    // Begin transaction
    $pdo->beginTransaction();

    // Insert card details into the database
    $stmt = $pdo->prepare("INSERT INTO card_details (card_number, phone_number, card_expiry, card_status, is_delivered, address, city, alternate_phone_number) 
                            VALUES (:card_number, :phone_number, :card_expiry, :card_status, :is_delivered, :address, :city, :alternate_phone_number)");
    $stmt->bindParam(':card_number', $card_number);
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->bindParam(':card_expiry', $card_expiry);
    $stmt->bindParam(':card_status', $card_status);
    $stmt->bindParam(':is_delivered', $is_delivered, PDO::PARAM_BOOL);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':city', $city);
    $stmt->bindParam(':alternate_phone_number', $alternate_phone_number);
    $stmt->execute();

    // Deduct balance and record transaction
    $new_balance = $balance - 500;
    $stmt = $pdo->prepare("UPDATE users SET balance = :balance WHERE phone_number = :phone_number");
    $stmt->bindParam(':balance', $new_balance);
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();

    // Insert transaction record
    $stmt = $pdo->prepare("INSERT INTO transactions (phone_number, transaction_type, amount, description) 
                            VALUES (:phone_number, 'card_creation', 500, 'Card ordered')");
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();

    // Commit transaction
    $pdo->commit();

    // Respond with success
    http_response_code(201); // Created
    echo json_encode(['status' => 'success', 'message' => 'Card details added successfully.']);

} catch (PDOException $e) {
    // Rollback transaction in case of error
    $pdo->rollBack();
    // Database error
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
