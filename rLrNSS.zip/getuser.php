<?php
// Database connection parameters
$host = 'localhost'; // Change as needed
$dbname = 'u596352071_flarepaydb_pak'; // Change as needed
$user = 'u596352071_flarepay_pk112'; // Change as needed
$pass = 'HuzaifaAbid12@@'; // Change as needed

header('Content-Type: application/json'); // Set the content type to JSON

// Example token for demonstration purposes
$validToken = 'afb3884e-10a5-4de8-b5b5-17a910b7a55d';

// Function to sanitize input
function sanitize_input($data) {
    return htmlspecialchars(strip_tags($data));
}

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check for token in headers
    $headers = apache_request_headers();
    if (!isset($headers['Authorization']) || $headers['Authorization'] !== $validToken) {
        http_response_code(401); // Unauthorized
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
        exit;
    }

    // Retrieve and sanitize data from GET request
    $phone_number = isset($_GET['phone_number']) ? sanitize_input($_GET['phone_number']) : '';
    $pin = isset($_GET['pin']) ? sanitize_input($_GET['pin']) : '';

    // Check if phone number and PIN are provided
    if (empty($phone_number) || empty($pin)) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Phone number and PIN are required.']);
        exit;
    }

    // Prepare SQL statement to get user data
    $stmt = $pdo->prepare("SELECT phone_number, name, dob, cnic_number, cnic_issue_date, cnic_expiry_date, account_status, device_id, user_address, date_account_created, balance, user_account_pin
        FROM users WHERE phone_number = :phone_number");

    // Bind parameter to the SQL statement
    $stmt->bindParam(':phone_number', $phone_number);
    $stmt->execute();

    // Fetch user data
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Check if the provided PIN matches the one in the database
        if ($user['user_account_pin'] === $pin) {
            // Respond with user data
            http_response_code(200); // OK
            echo json_encode([
               
                    'phone_number' => $user['phone_number'],
                    'name' => $user['name'],
                    'dob' => $user['dob'],
                    'cnic_number' => $user['cnic_number'],
                    'cnic_issue_date' => $user['cnic_issue_date'],
                    'cnic_expiry_date' => $user['cnic_expiry_date'],
                    'account_status' => $user['account_status'],
                    'device_id' => $user['device_id'],
                    'user_address' => $user['user_address'],
                    'date_account_created' => $user['date_account_created'],
                    'balance' => $user['balance']
                
            ]);
        } else {
            // PIN does not match
            http_response_code(400); // Bad Request
            echo json_encode([
                'status' => 'error',
                'message' => 'Incorrect PIN.'
            ]);
        }
    } else {
        // User not found
        http_response_code(404); // Not Found
        echo json_encode([
            'status' => 'error',
            'message' => 'User not found.'
        ]);
    }

} catch (PDOException $e) {
    // Database error
    http_response_code(500); // Internal Server Error status
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
