<?php
// Database connection parameters
$host = 'localhost';
$dbname = 'u596352071_flarepaydb_pak';
$user = 'u596352071_flarepay_pk112';
$pass = 'HuzaifaAbid12@@';

// Create a new MySQLi instance
$mysqli = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($mysqli->connect_error) {
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error]);
    exit;
}

// Get raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate JSON data
if (json_last_error() !== JSON_ERROR_NONE) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
    exit;
}

// Retrieve and sanitize data from JSON
$user_phone_number = isset($data['user_phone_number']) ? $mysqli->real_escape_string($data['user_phone_number']) : '';
$topup_amount = isset($data['topup_amount']) ? (float) $data['topup_amount'] : 0.0;

if (empty($user_phone_number) || $topup_amount <= 0) {
    header('Content-Type: application/json');
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'User phone number and valid topup amount are required.']);
    exit;
}

// Begin transaction
$mysqli->begin_transaction();

try {
    // Fetch user details
    $user_result = $mysqli->query("SELECT * FROM users WHERE phone_number = '$user_phone_number'");

    if ($user_result->num_rows === 0) {
        header('Content-Type: application/json');
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'User not found.']);
        $mysqli->rollback();
        exit;
    }

    $user = $user_result->fetch_assoc();
    $current_balance = $user['balance'];
    $user_name = $user['name']; // Fetch user name

    // Update user balance
    $new_balance = $current_balance + $topup_amount;
    $mysqli->query("UPDATE users SET balance = '$new_balance' WHERE phone_number = '$user_phone_number'");

    // Record transaction
    $transaction_id = uniqid(); // Generate a unique transaction ID
    $mysqli->query("INSERT INTO transactions (transaction_id, phone_number, transaction_type, amount, transaction_fee, balance_before_transaction, description, timestamp, sender_name, receiver_name, sender_phone_number, receiver_phone_number) VALUES ('$transaction_id', '$user_phone_number', 'receive', '$topup_amount', '0.00', '$current_balance', 'Top-up balance', NOW(), 'System', '$user_name', '', '$user_phone_number')");

    // Commit transaction
    $mysqli->commit();

    // Respond with success
    header('Content-Type: application/json');
    header_remove('X-Powered-By');
    header_remove('platform');
    http_response_code(200); // OK
    echo json_encode([
        'status' => 'success',
        'message' => 'Balance topped up successfully.',
        'transaction_id' => $transaction_id
    ]);

} catch (Exception $e) {
    // Rollback transaction if there is an error
    $mysqli->rollback();
    header('Content-Type: application/json');
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'status' => 'error',
        'message' => 'Top-up failed: ' . $e->getMessage()
    ]);
}

$mysqli->close();
?>
